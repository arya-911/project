import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.transaction.annotation.Transactional;

import entity.CompliantTypeEntity;

@RepositoryDefinition(idClass = Integer.class, domainClass = CompliantTypeEntity.class)
@Transactional(value = "txManager")
public interface CompliantTypeDao {
	List<CompliantTypeEntity> findAll();
}
